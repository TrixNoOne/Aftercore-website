AFTERCORE — PRESS KIT
last updated 13 october 2026

what is inside
  aftercore-press-sheet.pdf   one page: what we build, the facts, brand and contacts
  logos/                      the wordmark, in two cuts
      aftercore-logo-small-dark-bg.png      the small cut, for dark backgrounds
      aftercore-logo-extended-white-bg.png  the extended cut, for white backgrounds
  images/                     product renders, made in house, high resolution
      aftercore-x40g-pcb-horizontal.png
      aftercore-x40g-pcb-vertical.png
      aftercore-x40g-flare-mechanism.png
  (this file)

how you may use it
  - write about AfterCore freely, including the product renders and the wordmark.
  - the marks come in two cuts; pick the one that matches the background it sits on.
  - do not alter, recolour, stretch or crop the marks; keep the clear space.
  - the renders are of prototypes. label them as such if you caption them.
  - do not suggest partnership, endorsement or affiliation that does not exist.
  - AfterCore is not affiliated with, endorsed by or connected to PixArt Imaging Inc.
    PAW 3950 is a PixArt Imaging product; its trademarks are the property of their owners.

copyright
  © 2026 AfterCore. All rights reserved. The marks and renders in this kit are released for
  editorial use to report on AfterCore, under the usage rules published at aftcre.com/press.html.
  Nothing here is an offer to invest or to sell.

contact
  press      trix@aftcre.com   (subject: press)
  general    trix@aftcre.com
  phone      +39 388 892 9341
  site       https://aftcre.com
  linkedin   https://www.linkedin.com/in/tristano-rigoli-aftcre
